import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-todo',
  imports: [CommonModule, FormsModule],
  templateUrl: './todo.component.html',
  styleUrl: './todo.component.css'
})
export class TodoComponent {
  newTask = '';
  tasks: { text: string, editing: boolean, id: number }[] = [];
  currentId = 0;

  addTask() {
    if (this.newTask.trim()) {
      this.tasks.push({ text: this.newTask, editing: false, id: this.currentId++ });
      this.newTask = '';
    }
  }

  deleteTask(index: number) {
    this.tasks = this.tasks.filter(task => task.id !== this.tasks[index].id);
  }

  startEdit(index: number) {
    this.tasks[index].editing = true;
  }

  saveEdit(index: number) {
    this.tasks[index].editing = false;
  }
}
