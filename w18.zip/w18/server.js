const express = require('express');
const mongoose = require('mongoose');
const app = express();
require('dotenv').config();

// Connect to MongoDB
mongoose.connect("mongodb+srv://gunjalaishwarya625:IdSqBWbEb3IlEP1b@cluster0.owhxijq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");

// Song Schema
const songSchema = new mongoose.Schema({
    Songname: String,
    Film: String,
    Music_director: String,
    Singer: String,
    Actor: { type: String, default: 'N/A' },
    Actress: { type: String, default: 'N/A' }
});

const Song = mongoose.model('songdetails', songSchema);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Insert sample songs (Task c)
app.get('/insert-sample', async (req, res) => {
    const sampleSongs = [
        {
            Songname: "ABC",
            Film: "DEF",
            Music_director: "GHI",
            Singer: "JKL"
        },
        {
            Songname: "Moonlight Sonata",
            Film: "Beethoven's Life",
            Music_director: "Ludwig van Beethoven",
            Singer: "Piano Instrumental"
        },
        // Add 3 more sample songs
    ];

    try {
        await Song.insertMany(sampleSongs);
        res.send('Sample songs inserted successfully');
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Display count and documents (Task d)
app.get('/songs', async (req, res) => {
    try {
        const count = await Song.countDocuments();
        const songs = await Song.find();
        res.send(`Total songs: ${count}<br>${JSON.stringify(songs)}`);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// List Music Director songs (Task e)
app.get('/music-director-songs', async (req, res) => {
    const { director } = req.query;
    try {
        const songs = await Song.find({ Music_director: director });
        res.send(songs);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// List Director-Singer combination (Task f)
app.get('/director-singer-songs', async (req, res) => {
    const { director, singer } = req.query;
    try {
        const songs = await Song.find({ 
            Music_director: director,
            Singer: singer
        });
        res.send(songs);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Delete song (Task g)
app.delete('/delete-song/:id', async (req, res) => {
    try {
        await Song.findByIdAndDelete(req.params.id);
        res.send('Song deleted successfully');
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Add new song (Task h)
app.post('/add-song', async (req, res) => {
    try {
        const newSong = new Song(req.body);
        await newSong.save();
        res.status(201).send(newSong);
    } catch (err) {
        res.status(400).send(err.message);
    }
});

// Singer-Film combination (Task i)
app.get('/singer-film-songs', async (req, res) => {
    const { singer, film } = req.query;
    try {
        const songs = await Song.find({ 
            Singer: singer,
            Film: film
        });
        res.send(songs);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Update with Actor/Actress (Task j)
app.put('/update-song/:id', async (req, res) => {
    try {
        const updatedSong = await Song.findByIdAndUpdate(
            req.params.id,
            { $set: { 
                Actor: req.body.Actor,
                Actress: req.body.Actress 
            }},
            { new: true }
        );
        res.send(updatedSong);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Display in table format (Task k)
app.get('/songs-table', async (req, res) => {
    try {
        const songs = await Song.find();
        let html = `
            <table border="1">
                <tr>
                    <th>Song Name</th>
                    <th>Film Name</th>
                    <th>Music Director</th>
                    <th>Singer</th>
                    <th>Actor</th>
                    <th>Actress</th>
                </tr>
        `;
        
        songs.forEach(song => {
            html += `
                <tr>
                    <td>${song.Songname}</td>
                    <td>${song.Film}</td>
                    <td>${song.Music_director}</td>
                    <td>${song.Singer}</td>
                    <td>${song.Actor}</td>
                    <td>${song.Actress}</td>
                </tr>
            `;
        });
        
        html += '</table>';
        res.send(html);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));