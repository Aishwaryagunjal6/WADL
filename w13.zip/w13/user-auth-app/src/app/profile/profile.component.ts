import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-profile',
  imports: [CommonModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {
  currentUser: any;

  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser') || 'null');
  }
}
